﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public enum SaleType
    {
        Genre = 1,
        Author = 2,
        Publisher = 3,
        Date = 4,
        Year = 5
    }
}
