﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject
{
    public class DailyReport
    {
        public int itemsCount = 0;
        public int booksCount = 0;
        public int magazineCount = 0;
        public int rentedCount = 0;
    }
}
